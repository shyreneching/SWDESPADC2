package Model;

public abstract class SongFactory {

    public abstract SongInterface SongFactoryMethod(String filelocation);
}
