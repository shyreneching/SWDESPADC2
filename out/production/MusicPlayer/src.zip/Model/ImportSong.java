package Model;

public interface ImportSong {
    public static SongInterface createSong(String filename) {
        return null;
    }
}
